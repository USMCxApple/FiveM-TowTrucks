Citizen.CreateThread(function()
	AddTextEntry('0x7976E285', 'Flatbed Towtruck')
end)