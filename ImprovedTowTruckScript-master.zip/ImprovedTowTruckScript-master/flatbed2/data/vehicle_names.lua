Citizen.CreateThread(function()
	AddTextEntry('0x8FC50F21', 'flatbed2')
end)